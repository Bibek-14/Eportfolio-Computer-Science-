from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username, password):
        # Connection variables
        USER = 'aacuser'
        PASS = 'password'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 33283
        DB = 'AAC'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Create method to insert a document
    def create(self, data):
        if data is not None:
            try:
                result = self.collection.insert_one(data)  
                return True if result.acknowledged else False
            except Exception as e:
                print(f"Error: {e}")
                return False
        else:
            raise ValueError("Nothing to save because the data parameter is empty")

    # Read method to query documents
    def read(self, query):
        try:
            results = self.collection.find(query)  # Find matching documents
            documents = [doc for doc in results]
            return documents if documents else []
        except Exception as e:
            print(f"Error: {e}")
            return []
        
    # Update method to modify existing documents
    def update(self, query, new_values, multiple=False):
        if query and new_values:
            try:
                if multiple:
                    result = self.collection.update_many(query, {'$set': new_values})
                else:
                    result = self.collection.update_one(query, {'$set': new_values})
                return result.modified_count
            except Exception as e:
                print(f"Error: {e}")
                return 0
        else:
            raise ValueError("Query and update values cannot be empty")
    
    # Delete method to remove documents
    def delete(self, query, multiple=False):
        if query:
            try:
                if multiple:
                    result = self.collection.delete_many(query)
                else:
                    result = self.collection.delete_one(query)
                return result.deleted_count
            except Exception as e:
                print(f"Error: {e}")
                return 0
        else:
            raise ValueError("Query cannot be empty")