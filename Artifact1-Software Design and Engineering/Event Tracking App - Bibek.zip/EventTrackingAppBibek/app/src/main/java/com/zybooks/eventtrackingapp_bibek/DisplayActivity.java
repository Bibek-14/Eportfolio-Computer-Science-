package com.zybooks.eventtrackingapp_bibek;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DisplayActivity extends AppCompatActivity {

    private RecyclerView rvDataGrid;
    private EventAdapter adapter;
    private List<Event> eventList;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        rvDataGrid = findViewById(R.id.rvDataGrid);
        rvDataGrid.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DatabaseHelper(this);
        eventList = dbHelper.getAllEvents();

        adapter = new EventAdapter(eventList);
        rvDataGrid.setAdapter(adapter);

        adapter.setOnItemClickListener(position -> {
            Event event = eventList.get(position);
            dbHelper.deleteEvent(event);
            eventList.remove(position);
            adapter.notifyItemRemoved(position);
        });
    }

    public void addNewData(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Event");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        final EditText inputName = new EditText(this);
        inputName.setHint("Event Name");
        layout.addView(inputName);

        final EditText inputDate = new EditText(this);
        inputDate.setHint("Date (YYYY-MM-DD)");
        layout.addView(inputDate);

        builder.setView(layout);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String name = inputName.getText().toString().trim();
            String date = inputDate.getText().toString().trim();

            if (!name.isEmpty() && !date.isEmpty()) {
                Event event = new Event(name, date);
                dbHelper.addEvent(event);
                eventList.add(0, event); // add at top
                adapter.notifyItemInserted(0);
                rvDataGrid.scrollToPosition(0);
            } else {
                Toast.makeText(DisplayActivity.this, "Please enter event name and date", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}