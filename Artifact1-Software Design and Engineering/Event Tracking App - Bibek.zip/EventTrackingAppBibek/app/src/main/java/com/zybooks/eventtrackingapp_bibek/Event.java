package com.zybooks.eventtrackingapp_bibek;

public class Event {
    private final String name;
    private final String date;

    public Event(String name, String date) {
        this.name = name;
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }
}