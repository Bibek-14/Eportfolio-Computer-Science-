package com.zybooks.eventtrackingapp_bibek;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateAccountActivity extends AppCompatActivity {

    private EditText etNewUsername;
    private EditText etNewPassword;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        etNewUsername = findViewById(R.id.etNewUsername);
        etNewPassword = findViewById(R.id.etNewPassword);
        dbHelper = new DatabaseHelper(this);
    }

    public void registerNewUser(View view) {
        String newUsername = etNewUsername.getText().toString().trim();
        String newPassword = etNewPassword.getText().toString().trim();

        if (newUsername.isEmpty() || newPassword.isEmpty()) {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dbHelper.checkUserExists(newUsername)) {
            Toast.makeText(this, "Username already exists. Please choose another one", Toast.LENGTH_SHORT).show();
            return;
        }

        long id = dbHelper.addUser(newUsername, newPassword);
        if (id > 0) {
            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
            finish(); //back to the login screen
        } else {
            Toast.makeText(this, "Failed to create account", Toast.LENGTH_SHORT).show();
        }
    }
}