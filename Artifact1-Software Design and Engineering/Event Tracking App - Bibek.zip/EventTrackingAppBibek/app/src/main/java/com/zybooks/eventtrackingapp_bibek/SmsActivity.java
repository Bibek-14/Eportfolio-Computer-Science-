package com.zybooks.eventtrackingapp_bibek;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 101;
    private TextView tvSmsStatus;
    private TextView tvMessagePreview;
    private Button btnRequestPermission;
    private Button btnSendSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        tvSmsStatus = findViewById(R.id.tvSmsStatus);
        tvMessagePreview = findViewById(R.id.tvMessagePreview);
        btnRequestPermission = findViewById(R.id.btnRequestPermission);
        btnSendSms = findViewById(R.id.btnSendSms);

        checkSmsPermission();
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            // Permission already granted
            tvSmsStatus.setText(R.string.sms_permission_granted);
            tvMessagePreview.setVisibility(View.VISIBLE);
            btnSendSms.setVisibility(View.VISIBLE);
            btnRequestPermission.setVisibility(View.GONE);
        } else {
            // Permission not granted
            tvSmsStatus.setText(R.string.sms_permission_denied);
            tvMessagePreview.setVisibility(View.INVISIBLE);
            btnSendSms.setVisibility(View.INVISIBLE);
            btnRequestPermission.setVisibility(View.VISIBLE);
        }
    }

    public void requestSmsPermission(View view) {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                tvSmsStatus.setText(R.string.sms_permission_granted);
                tvMessagePreview.setVisibility(View.VISIBLE);
                btnSendSms.setVisibility(View.VISIBLE);
                btnRequestPermission.setVisibility(View.GONE);
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                tvSmsStatus.setText(R.string.sms_permission_denied);
                tvMessagePreview.setVisibility(View.INVISIBLE);
                btnSendSms.setVisibility(View.INVISIBLE);
                btnRequestPermission.setVisibility(View.VISIBLE);
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void sendAlertSms(View view) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            String phoneNumber = "111_1111_1111";
            String message = getString(R.string.sms_alert_message); // Define this in strings.xml

            SmsManager smsManager = SmsManager.getDefault();
            try {
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "SMS alert sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "SMS failed to send: " + e.getMessage(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show();
        }
    }
}